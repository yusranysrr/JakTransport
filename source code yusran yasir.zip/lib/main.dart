// main.dart
import 'package:flutter/material.dart';
import 'screens/transjakarta_screen.dart';
import 'screens/mrt_screen.dart';
import 'screens/lrt_screen.dart';
import 'screens/about_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // Tentukan warna coklat yang konsisten di satu tempat
  // Variabel ini sudah ada di kode Anda dan tidak akan menyebabkan error jika digunakan di sini.
  static const Color _primaryBrown = Color(0xFF795548); // Ini adalah Colors.brown
  static const Color _darkBrown = Color(0xFF5D4037); // Ini adalah Colors.brown[800]
  static const Color _lightBrown = Color(0xFFBCAAA4); // Ini adalah Colors.brown[200]

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Transportasi Jakarta',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFFFFAF3), // Soft background
        colorScheme: ColorScheme.fromSeed(
          seedColor: _primaryBrown, // Menggunakan warna coklat
          primary: _primaryBrown,
        ),
        fontFamily: 'Poppins',
        textTheme: const TextTheme(
          bodyLarge: TextStyle(fontSize: 16),
          bodyMedium: TextStyle(fontSize: 14),
          titleLarge: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: _primaryBrown, // Latar belakang AppBar: Coklat
          foregroundColor: Colors.white, // Ikon dan teks selain judul: Putih
          elevation: 0,
          // Ini adalah kunci untuk warna judul AppBar (Transjakarta, MRT Jakarta)
          titleTextStyle: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white, // Warna font judul: Putih
            // Jika Anda merasa putih kurang "friendly", ganti menjadi _lightBrown
            // color: _lightBrown, // Coklat muda, mungkin kurang kontras
          ),
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: Colors.white, // Latar belakang BottomNavBar: Putih
          selectedItemColor: _primaryBrown, // Item terpilih: Coklat
          unselectedItemColor: _lightBrown, // Item tidak terpilih: Coklat muda
          selectedLabelStyle: TextStyle(fontWeight: FontWeight.w600),
          showUnselectedLabels: true,
          type: BottomNavigationBarType.fixed,
        ),
        useMaterial3: true,
      ),
      home: const MainNavbar(),
    );
  }
}

class MainNavbar extends StatefulWidget {
  const MainNavbar({super.key});

  @override
  State<MainNavbar> createState() => _MainNavbarState();
}

class _MainNavbarState extends State<MainNavbar> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    const TransjakartaScreen(),
    const MrtScreen(),
    const LrtScreen(),
    const AboutScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.directions_bus_filled_rounded),
            label: 'Transjakarta',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.directions_railway_filled),
            label: 'MRT',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.tram_rounded),
            label: 'LRT',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.info_rounded),
            label: 'Tentang',
          ),
        ],
      ),
    );
  }
}
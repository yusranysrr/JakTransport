class LrtPenumpang {
  final String tahun;
  final String bulan;
  final String jenis;
  final String jumlah;
  final String periode;

  LrtPenumpang({
    required this.tahun,
    required this.bulan,
    required this.jenis,
    required this.jumlah,
    required this.periode,
  });

  factory LrtPenumpang.fromJson(Map<String, dynamic> json) {
    return LrtPenumpang(
      tahun: json['tahun'],
      bulan: json['bulan'],
      jenis: json['jenis'],
      jumlah: json['jumlah'],
      periode: json['periode_data'],
    );
  }
}

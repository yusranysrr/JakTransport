// Langkah 2: MODEL MRT
// File: lib/models/mrt_model.dart

class MrtPenumpang {
  final String periode;
  final String bulan; // <<< PERUBAHAN DI BARIS INI: Menambahkan properti bulan
  final String jumlah;

  MrtPenumpang({
    required this.periode,
    required this.bulan, // <<< PERUBAHAN DI BARIS INI: Menambahkan bulan ke konstruktor
    required this.jumlah,
  });

  factory MrtPenumpang.fromJson(Map<String, dynamic> json) {
    return MrtPenumpang(
      periode: json['periode_data'] ?? '',
      bulan: json['bulan'] ?? '', // <<< PERUBAHAN DI BARIS INI: Memparsing 'bulan' dari JSON
      jumlah: json['jumlah_penumpang'] ?? '',
    );
  }
}

class MrtStasiun {
  final String wilayah;
  final String kecamatan;
  final String namaStasiun;
  final String alamat;

  MrtStasiun({
    required this.wilayah,
    required this.kecamatan,
    required this.namaStasiun,
    required this.alamat,
  });

  factory MrtStasiun.fromJson(Map<String, dynamic> json) {
    return MrtStasiun(
      wilayah: json['wilayah'] ?? '',
      kecamatan: json['kecamatan'] ?? '',
      namaStasiun: json['nama_stasiun'] ?? '',
      alamat: json['lokasi'] ?? '', // <<< PERUBAHAN DI BARIS INI: Memparsing 'lokasi' dari JSON untuk properti 'alamat'
    );
  }
}
// Langkah 1: MODEL DATA
// File: lib/models/transjakarta_model.dart

class TransjakartaJumlah {
  final String periode;
  final String triwulan;
  final String jenis;
  final String jumlahBus;
  final String jumlahPenumpang;

  TransjakartaJumlah({
    required this.periode,
    required this.triwulan,
    required this.jenis,
    required this.jumlahBus,
    required this.jumlahPenumpang,
  });

  factory TransjakartaJumlah.fromJson(Map<String, dynamic> json) {
    return TransjakartaJumlah(
      periode: json['periode_data'],
      triwulan: json['triwulan'],
      jenis: json['jenis_layanan'],
      jumlahBus: json['jumlah_bus'],
      jumlahPenumpang: json['jumlah_penumpang'],
    );
  }
}

class TransjakartaHalte {
  final String wilayah;
  final String kecamatan;
  final String kelurahan;
  final String namaHalte;
  final String lokasi;

  TransjakartaHalte({
    required this.wilayah,
    required this.kecamatan,
    required this.kelurahan,
    required this.namaHalte,
    required this.lokasi,
  });

  factory TransjakartaHalte.fromJson(Map<String, dynamic> json) {
    return TransjakartaHalte(
      wilayah: json['wilayah'],
      kecamatan: json['kecamatan'],
      kelurahan: json['kelurahan'],
      namaHalte: json['nama_halte'],
      lokasi: json['lokasi'],
    );
  }
}

class TransjakartaRute {
  final String kategori;
  final String kode;
  final String jurusan;

  TransjakartaRute({
    required this.kategori,
    required this.kode,
    required this.jurusan,
  });

  factory TransjakartaRute.fromJson(Map<String, dynamic> json) {
    return TransjakartaRute(
      kategori: json['kategori'],
      kode: json['kode'],
      jurusan: json['jurusan'],
    );
  }
}
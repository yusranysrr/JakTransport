import 'package:flutter/material.dart';
import '../models/transjakarta_model.dart';
import '../models/mrt_model.dart';
import '../models/lrt_model.dart';
// Jika Anda tidak ingin error, jangan import 'constants/app_colors.dart'
// jika Anda memilih tidak membuat file itu.

class Templates {
  // Widget Loading
  static Widget loadingWidget() {
    return const Center(child: CircularProgressIndicator());
  }

  // Widget Error
  static Widget errorWidget(String message) {
    return Center(child: Text("Error: $message"));
  }

  // --------------------------
  // Transjakarta Widgets
  // --------------------------

  static Widget jumlahCard(TransjakartaJumlah item) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              item.jenis,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: Colors.brown[800],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Periode: ${item.periode} | Triwulan: ${item.triwulan}",
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Bus: ${item.jumlahBus}",
                  style: TextStyle(
                    color: Colors.blueGrey,
                    fontSize: 14,
                  ),
                ),
                Text(
                  "Penumpang: ${item.jumlahPenumpang}",
                  style: TextStyle(
                    color: Colors.blueGrey,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  static Widget halteCard(TransjakartaHalte halte) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              halte.namaHalte,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: Colors.brown[800],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "${halte.lokasi} (${halte.kelurahan}, ${halte.kecamatan})",
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.bottomRight,
              child: Text(
                halte.wilayah,
                style: TextStyle(
                  color: Colors.blueGrey,
                  fontSize: 14,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Widget ruteCard(TransjakartaRute rute) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Kode: ${rute.kode}",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: Colors.brown[800],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Jurusan: ${rute.jurusan}",
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.bottomRight,
              child: Text(
                rute.kategori,
                style: TextStyle(
                  color: Colors.blueGrey,
                  fontSize: 14,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // MRT Widgets
  static Widget mrtPenumpangCard(MrtPenumpang item) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Periode: ${item.periode}",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: Colors.brown[800],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Bulan: ${_namaBulan(item.bulan)} | Jumlah Penumpang: ${item.jumlah}",
              style: TextStyle(
                color: Colors.blueGrey,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Widget mrtStasiunCard(MrtStasiun item) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              item.namaStasiun,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: Colors.brown[800],
              ),
            ),
            const SizedBox(height: 8), // Tetap ada spasi
            Text(
              "${item.kecamatan}, ${item.wilayah}", // <<< HANYA MENAMPILKAN KECAMATAN DAN WILAYAH
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // LRT Widgets
  static Widget lrtPenumpangCard(LrtPenumpang item) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Jenis: ${item.jenis} | Bulan: ${_namaBulan(item.bulan)}",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18,
                color: Colors.brown[800],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Tahun: ${item.tahun} | Periode: ${item.periode}",
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.bottomRight,
              child: Text(
                "Penumpang: ${item.jumlah}",
                style: TextStyle(
                  color: Colors.blueGrey,
                  fontSize: 14,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

String _namaBulan(String kodeBulan) {
  const bulan = {
    '1': 'Januari',
    '2': 'Februari',
    '3': 'Maret',
    '4': 'April',
    '5': 'Mei',
    '6': 'Juni',
    '7': 'Juli',
    '8': 'Agustus',
    '9': 'September',
    '10': 'Oktober',
    '11': 'November',
    '12': 'Desember',
    '01': 'Januari', // Menambahkan format '0x'
    '02': 'Februari',
    '03': 'Maret',
    '04': 'April',
    '05': 'Mei',
    '06': 'Juni',
    '07': 'Juli',
    '08': 'Agustus',
    '09': 'September',
  };
  return bulan[kodeBulan] ?? kodeBulan;
}
import 'package:flutter/material.dart';
import '../api/transjakarta_api.dart';
import '../models/transjakarta_model.dart';
import '../widget/templates.dart';
import 'transjakarta_detail_screen.dart';
import 'transjakarta_halte_detail_screen.dart';
import 'transjakarta_rute_detail_screen.dart'; // <<< BARIS BARU DITAMBAHKAN

class TransjakartaScreen extends StatefulWidget {
  const TransjakartaScreen({super.key});

  @override
  State<TransjakartaScreen> createState() => _TransjakartaScreenState();
}

class _TransjakartaScreenState extends State<TransjakartaScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = Theme.of(context).primaryColor;
    final Color textColorForAppBar = Colors.white;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Transjakarta',
          style: TextStyle(
            color: textColorForAppBar,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: primaryColor,
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(icon: Icon(Icons.directions_bus), text: 'Jumlah'),
            Tab(icon: Icon(Icons.location_on), text: 'Halte'),
            Tab(icon: Icon(Icons.alt_route), text: 'Rute'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Tab: Jumlah
          FutureBuilder(
            future: TransjakartaAPI.fetchJumlah(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Templates.loadingWidget();
              } else if (snapshot.hasError) {
                return Templates.errorWidget(snapshot.error.toString());
              } else {
                final data = snapshot.data as List<TransjakartaJumlah>;
                return ListView.builder(
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                    final item = data[index];
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => TransjakartaDetailScreen(
                              title: item.jenis,
                              periode: '${item.periode} | Triwulan: ${item.triwulan}',
                              bus: item.jumlahBus,
                              penumpang: item.jumlahPenumpang,
                            ),
                          ),
                        );
                      },
                      child: Templates.jumlahCard(item),
                    );
                  },
                );
              }
            },
          ),

          // Tab: Halte
          FutureBuilder(
            future: TransjakartaAPI.fetchHalte(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Templates.loadingWidget();
              } else if (snapshot.hasError) {
                return Templates.errorWidget(snapshot.error.toString());
              } else {
                final data = snapshot.data as List<TransjakartaHalte>;
                return ListView.builder(
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                    final halte = data[index];
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => TransjakartaHalteDetailScreen(halte: halte),
                          ),
                        );
                      },
                      child: Templates.halteCard(halte),
                    );
                  },
                );
              }
            },
          ),

          // Tab: Rute
          FutureBuilder(
            future: TransjakartaAPI.fetchRute(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Templates.loadingWidget();
              } else if (snapshot.hasError) {
                return Templates.errorWidget(snapshot.error.toString());
              } else {
                final data = snapshot.data as List<TransjakartaRute>;
                return ListView.builder(
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                    final rute = data[index]; // <<< BARIS INI DITAMBAHKAN
                    return GestureDetector( // <<< BARIS INI DITAMBAHKAN
                      onTap: () { // <<< BARIS INI DITAMBAHKAN
                        Navigator.push( // <<< BARIS INI DITAMBAHKAN
                          context, // <<< BARIS INI DITAMBAHKAN
                          MaterialPageRoute( // <<< BARIS INI DITAMBAHKAN
                            builder: (_) => TransjakartaRuteDetailScreen(rute: rute), // <<< BARIS INI DITAMBAHKAN
                          ), // <<< BARIS INI DITAMBAHKAN
                        ); // <<< BARIS INI DITAMBAHKAN
                      }, // <<< BARIS INI DITAMBAHKAN
                      child: Templates.ruteCard(rute), // <<< VARIABLE 'data[index]' DIUBAH MENJADI 'rute'
                    ); // <<< BARIS INI DITAMBAHKAN
                  },
                );
              }
            },
          ),
        ],
      ),
    );
  }
}
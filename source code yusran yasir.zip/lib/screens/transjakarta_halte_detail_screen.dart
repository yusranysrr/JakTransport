// lib/screens/transjakarta_halte_detail_screen.dart

import 'package:flutter/material.dart';
import '../models/transjakarta_model.dart'; // Menggunakan relative path, pastikan ini benar

class TransjakartaHalteDetailScreen extends StatelessWidget {
  final TransjakartaHalte halte;

  const TransjakartaHalteDetailScreen({Key? key, required this.halte}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = Theme.of(context).primaryColor;
    final Color textColorForAppBar = Colors.white; // Asumsi warna teks AppBar Anda

    return Scaffold(
      appBar: AppBar(
        title: Text(
          halte.namaHalte, // Judul AppBar adalah nama halte
          style: TextStyle(
            color: textColorForAppBar,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: primaryColor,
      ),
      body: SingleChildScrollView( // Tambahkan SingleChildScrollView agar bisa discroll jika konten banyak
        padding: const EdgeInsets.all(16.0),
        child: Card(
          elevation: 8.0, // Memberi efek bayangan pada card
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)), // Sudut membulat
          child: Padding(
            padding: const EdgeInsets.all(20.0), // Padding di dalam card
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Icon(
                    Icons.directions_bus_filled, // Ikon untuk halte
                    size: 80,
                    color: primaryColor, // Menggunakan primaryColor dari tema
                  ),
                ),
                const SizedBox(height: 24),

                // Detail Nama Halte
                _buildDetailItem(
                  context,
                  icon: Icons.push_pin, // Ikon untuk nama halte
                  label: 'Nama Halte',
                  value: halte.namaHalte,
                ),
                const SizedBox(height: 16),

                // Detail Wilayah
                _buildDetailItem(
                  context,
                  icon: Icons.location_city, // Ikon untuk wilayah
                  label: 'Wilayah',
                  value: halte.wilayah,
                ),
                const SizedBox(height: 16),

                // Detail Kecamatan
                _buildDetailItem(
                  context,
                  icon: Icons.map, // Ikon untuk kecamatan
                  label: 'Kecamatan',
                  value: halte.kecamatan,
                ),
                const SizedBox(height: 16),

                // Detail Kelurahan
                _buildDetailItem(
                  context,
                  icon: Icons.map_outlined, // Ikon untuk kelurahan
                  label: 'Kelurahan',
                  value: halte.kelurahan,
                ),
                const SizedBox(height: 16),

                // Detail Lokasi (Tambahan, bisa jadi link atau teks biasa)
                _buildDetailItem(
                  context,
                  icon: Icons.location_on, // Ikon untuk lokasi
                  label: 'Lokasi',
                  value: halte.lokasi,
                ),
                // Anda bisa menambahkan widget interaktif di sini,
                // seperti tombol untuk membuka Maps jika 'lokasi' adalah koordinat/URL
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Helper method untuk membangun setiap baris detail dengan ikon
  Widget _buildDetailItem(BuildContext context, {required IconData icon, required String label, required String value}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: Theme.of(context).colorScheme.secondary, size: 20), // Warna ikon dari colorScheme.secondary
            const SizedBox(width: 8),
            Text(
              '$label:',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).primaryColor, // Warna label dari primaryColor
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.only(left: 28.0), // Beri indentasi agar sejajar dengan teks
          child: Text(
            value,
            style: const TextStyle(fontSize: 18),
          ),
        ),
      ],
    );
  }
}
import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tentang Aplikasi'), // Judul AppBar
        // Warna AppBar background dan teks sudah diatur di main.dart
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 30.0), // Padding lebih proporsional
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center, // Pusatkan bagian atas
          children: [
            // --- Bagian Judul Aplikasi & Ikon Utama ---
            Icon(
              Icons.directions_bus_filled_rounded, // Ikon Bus besar dan menonjol
              size: 100, // Ukuran ikon diperbesar
              color: Colors.brown[600], // Warna coklat yang sedikit lebih terang dari 800
            ),
            const SizedBox(height: 20), // Jarak yang lebih besar
            Text(
              'Jak Transport',
              style: TextStyle(
                fontSize: 32, // Ukuran judul utama lebih besar
                fontWeight: FontWeight.bold,
                color: Colors.brown[800], // Warna coklat gelap
                letterSpacing: 0.5, // Sedikit spasi antar huruf
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10), // Jarak yang sedikit lebih kecil untuk versi
            Text(
              'Versi: 1.0.0', // Versi aplikasi
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[700], // Warna abu-abu yang lebih gelap
                fontStyle: FontStyle.italic,
              ),
            ),
            const SizedBox(height: 40), // Jarak yang signifikan sebelum deskripsi

            // --- Divider (Garis Pembatas) ---
            Divider(
              color: Colors.brown[200], // Warna pembatas sesuai tema
              thickness: 1.5, // Ketebalan pembatas
              indent: 20, // Jarak dari kiri
              endIndent: 20, // Jarak dari kanan
            ),
            const SizedBox(height: 40), // Jarak setelah pembatas

            // --- Bagian Deskripsi Aplikasi ---
            Align(
              alignment: Alignment.centerLeft, // Rata kiri untuk judul bagian
              child: Text(
                'Deskripsi Aplikasi',
                style: TextStyle(
                  fontSize: 22, // Ukuran judul bagian lebih besar
                  fontWeight: FontWeight.bold,
                  color: Colors.brown[700], // Warna coklat yang lebih menonjol
                ),
              ),
            ),
            const SizedBox(height: 12), // Jarak antara judul bagian dan konten
            Text(
              'Aplikasi "Transportasi Jakarta" adalah platform interaktif yang dirancang untuk mempermudah akses informasi transportasi publik di Ibu Kota Jakarta. Dengan fokus pada data real-time dan akurat, aplikasi ini menyajikan detail lengkap mengenai Transjakarta, MRT, dan LRT.\n\nPengguna dapat dengan mudah memantau rute, jadwal, dan ketersediaan layanan, serta mendapatkan informasi terkini terkait jumlah penumpang dan statistik stasiun. Tujuan utama aplikasi ini adalah mendukung mobilitas warga Jakarta dengan menyediakan sumber informasi transportasi yang handal dan mudah diakses.\n\nSeluruh data yang disajikan dalam aplikasi ini bersumber langsung dari portal resmi Open Data Jakarta, menjamin keakuratan dan keandalan informasi yang Anda terima.',
              style: TextStyle(
                fontSize: 16,
                height: 1.6, // Spasi baris lebih lebar untuk keterbacaan
                color: Colors.grey[800], // Warna teks biasa lebih gelap untuk kontras
              ),
              textAlign: TextAlign.justify, // Rata kanan kiri
            ),
            const SizedBox(height: 40), // Jarak setelah deskripsi

            // --- Divider ---
            Divider(
              color: Colors.brown[200],
              thickness: 1.5,
              indent: 20,
              endIndent: 20,
            ),
            const SizedBox(height: 40),

            // --- Bagian Dibuat Oleh ---
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Dibuat oleh',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.brown[700],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Icon(Icons.code_rounded, color: Colors.brown[800], size: 24), // Ikon kode/pengembang
                const SizedBox(width: 12), // Jarak ikon dan teks
                Text(
                  'Yusran Yasir - Politeknik Digital Boash',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 40),

            // --- Divider ---
            Divider(
              color: Colors.brown[200],
              thickness: 1.5,
              indent: 20,
              endIndent: 20,
            ),
            const SizedBox(height: 40),

            // --- Bagian Sumber Data ---
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Sumber Data',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.brown[700],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start, // Rata atas jika teks link panjang
              children: [
                Icon(Icons.public_rounded, color: Colors.brown[800], size: 24), // Ikon globe/public
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Portal Resmi Open Data Jakarta:\nhttps://data.jakarta.go.id',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.blue[700],
                      decoration: TextDecoration.underline,
                      height: 1.4, // Spasi baris untuk URL
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30), // Spasi di bagian paling bawah
          ],
        ),
      ),
    );
  }
}
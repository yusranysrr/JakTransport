import 'package:flutter/material.dart';
import '../api/mrt_api.dart';
import '../models/mrt_model.dart';
import '../widget/templates.dart';
import 'mrt_penumpang_detail_screen.dart';
import 'mrt_stasiun_detail_screen.dart'; // <<< BARIS INI DITAMBAHKAN

class MrtScreen extends StatefulWidget {
  const MrtScreen({super.key});

  @override
  State<MrtScreen> createState() => _MrtScreenState();
}

class _MrtScreenState extends State<MrtScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Menentukan warna tema untuk AppBar (sesuai gaya TransjakartaScreen)
    final Color primaryColor = Theme.of(context).primaryColor;
    final Color textColorForAppBar = Colors.white;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'MRT Jakarta',
          style: TextStyle(
            color: textColorForAppBar, // Menggunakan warna teks yang konsisten
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: primaryColor, // Menggunakan warna primary dari tema
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(icon: Icon(Icons.people), text: 'Penumpang'),
            Tab(icon: Icon(Icons.location_city), text: 'Stasiun'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // Tab: Penumpang (tidak ada perubahan dari update sebelumnya)
          FutureBuilder(
            future: MrtAPI.fetchPenumpang(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Templates.loadingWidget();
              } else if (snapshot.hasError) {
                return Templates.errorWidget(snapshot.error.toString());
              } else {
                final data = snapshot.data as List<MrtPenumpang>;
                return ListView.builder(
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                    final penumpang = data[index];
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => MrtPenumpangDetailScreen(penumpang: penumpang),
                          ),
                        );
                      },
                      child: Templates.mrtPenumpangCard(penumpang),
                    );
                  },
                );
              }
            },
          ),

          // Tab: Stasiun <<< PERUBAHAN DIMULAI DARI SINI
          FutureBuilder(
            future: MrtAPI.fetchStasiun(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Templates.loadingWidget();
              } else if (snapshot.hasError) {
                return Templates.errorWidget(snapshot.error.toString());
              } else {
                final data = snapshot.data as List<MrtStasiun>;
                return ListView.builder(
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                    final stasiun = data[index]; // <<< BARIS INI DITAMBAHKAN
                    return GestureDetector( // <<< BARIS INI DITAMBAHKAN (MEMBUNGKUS CARD DENGAN DETEKTOR KLIK)
                      onTap: () { // <<< BARIS INI DITAMBAHKAN (AKSI KETIKA CARD DIKLIK)
                        Navigator.push( // <<< BARIS INI DITAMBAHKAN (NAVIGASI KE HALAMAN DETAIL)
                          context,
                          MaterialPageRoute(
                            builder: (_) => MrtStasiunDetailScreen(stasiun: stasiun), // <<< BARIS INI DITAMBAHKAN (MENERUSKAN DATA OBJEK 'stasiun')
                          ),
                        );
                      },
                      child: Templates.mrtStasiunCard(stasiun), // <<< PERUBAHAN DI BARIS INI (data[index] menjadi stasiun)
                    ); // <<< BARIS INI DITAMBAHKAN (PENUTUP GestureDetector)
                  },
                );
              }
            },
          ),
        ],
      ),
    );
  }
}
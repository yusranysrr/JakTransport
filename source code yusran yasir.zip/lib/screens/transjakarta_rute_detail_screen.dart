// lib/screens/transjakarta_rute_detail_screen.dart

import 'package:flutter/material.dart';
import '../models/transjakarta_model.dart'; // Menggunakan relative path, pastikan ini benar

class TransjakartaRuteDetailScreen extends StatelessWidget {
  final TransjakartaRute rute; // Menggunakan nama variabel 'rute'

  const TransjakartaRuteDetailScreen({Key? key, required this.rute}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = Theme.of(context).primaryColor;
    final Color textColorForAppBar = Colors.white; // Asumsi warna teks AppBar Anda

    return Scaffold(
      appBar: AppBar(
        title: Text(
          rute.jurusan, // Judul AppBar akan menampilkan jurusan rute
          style: TextStyle(
            color: textColorForAppBar,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: primaryColor,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          elevation: 8.0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Icon(
                    Icons.alt_route, // Ikon untuk rute
                    size: 80,
                    color: primaryColor,
                  ),
                ),
                const SizedBox(height: 24),

                // Detail Jurusan
                _buildDetailItem(
                  context,
                  icon: Icons.route, // Ikon untuk jurusan
                  label: 'Jurusan',
                  value: rute.jurusan,
                ),
                const SizedBox(height: 16),

                // Detail Kode Rute
                _buildDetailItem(
                  context,
                  icon: Icons.vpn_key, // Ikon untuk kode
                  label: 'Kode Rute',
                  value: rute.kode,
                ),
                const SizedBox(height: 16),

                // Detail Kategori
                _buildDetailItem(
                  context,
                  icon: Icons.category, // Ikon untuk kategori
                  label: 'Kategori',
                  value: rute.kategori,
                ),
                // Anda bisa menambahkan detail lain jika ada di model Rute Anda
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Helper method untuk membangun setiap baris detail dengan ikon
  Widget _buildDetailItem(BuildContext context, {required IconData icon, required String label, required String value}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: Theme.of(context).colorScheme.secondary, size: 20),
            const SizedBox(width: 8),
            Text(
              '$label:',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).primaryColor,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.only(left: 28.0),
          child: Text(
            value,
            style: const TextStyle(fontSize: 18),
          ),
        ),
      ],
    );
  }
}
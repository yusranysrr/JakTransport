import 'package:flutter/material.dart';
import '../models/lrt_model.dart'; // Pastikan path ini benar

class LrtDetailScreen extends StatelessWidget {
  final LrtPenumpang lrtData;

  const LrtDetailScreen({Key? key, required this.lrtData}) : super(key: key);

  // Fungsi pembantu untuk mengkonversi angka bulan ke nama bulan
  String getMonthName(String monthNumber) {
    switch (monthNumber) {
      case '1': return 'Januari';
      case '2': return 'Februari';
      case '3': return 'Maret';
      case '4': return 'April';
      case '5': return 'Mei';
      case '6': return 'Juni';
      case '7': return 'Juli';
      case '8': return 'Agustus';
      case '9': return 'September';
      case '10': return 'Oktober';
      case '11': return 'November';
      case '12': return 'Desember';
      default: return 'Bulan Tidak Dikenal';
    }
  }

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = Theme.of(context).primaryColor; // Menggunakan primaryColor dari tema
    final Color textColorForAppBar = Colors.white; // Contoh warna teks AppBar

    String bulanNama = getMonthName(lrtData.bulan);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Detail Penumpang LRT ${bulanNama}', // Judul AppBar
          style: TextStyle(
            color: textColorForAppBar,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: primaryColor, // Latar belakang AppBar menggunakan primaryColor tema
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0), // Padding di luar Card
        child: Card(
          elevation: 8.0, // Elemasi Card
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)), // Bentuk Card
          child: Padding(
            padding: const EdgeInsets.all(20.0), // Padding di dalam Card
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Icon(
                    Icons.train, // Ikon untuk LRT
                    size: 80,
                    color: primaryColor, // Warna ikon menggunakan primaryColor tema
                  ),
                ),
                const SizedBox(height: 24), // Spasi setelah ikon

                // Detail Bulan
                _buildDetailItem(
                  context,
                  icon: Icons.calendar_today,
                  label: 'Bulan',
                  value: bulanNama,
                ),
                const SizedBox(height: 16), // Spasi antar detail item

                // Detail Tahun
                _buildDetailItem(
                  context,
                  icon: Icons.date_range,
                  label: 'Tahun',
                  value: lrtData.tahun,
                ),
                const SizedBox(height: 16),

                // Detail Jenis
                _buildDetailItem(
                  context,
                  icon: Icons.alt_route, // Ikon untuk jenis transportasi
                  label: 'Jenis Transportasi',
                  value: lrtData.jenis,
                ),
                const SizedBox(height: 16),

                // Detail Jumlah Penumpang
                _buildDetailItem(
                  context,
                  icon: Icons.people_alt, // Ikon untuk jumlah penumpang
                  label: 'Jumlah Penumpang',
                  value: '${lrtData.jumlah} Orang',
                ),
                const SizedBox(height: 16),

                // Detail Periode Data
                _buildDetailItem(
                  context,
                  icon: Icons.schedule,
                  label: 'Periode Data',
                  value: lrtData.periode,
                ),
                const SizedBox(height: 16),

                // Anda bisa menambahkan informasi tambahan di sini jika ada
                // Misalnya:
                // Text('Informasi Lebih Lanjut: Data ini menunjukkan ...'),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Helper method untuk membangun setiap baris detail dengan ikon (diadaptasi dari MRT Detail Screen)
  Widget _buildDetailItem(BuildContext context, {required IconData icon, required String label, required String value}) {
    // Meniru gaya _buildDetailItem dari mrt_stasiun_detail_screen.dart
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            // Menggunakan secondary color dari tema, atau warna kustom jika diinginkan
            Icon(icon, color: Theme.of(context).colorScheme.secondary, size: 20),
            const SizedBox(width: 8),
            Text(
              '$label:',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).primaryColor, // Menggunakan primaryColor untuk label
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.only(left: 28.0), // Indentasi nilai
          child: Text(
            value,
            style: const TextStyle(fontSize: 18),
          ),
        ),
      ],
    );
  }
}
import 'package:flutter/material.dart';
import '../api/lrt_api.dart';
import '../models/lrt_model.dart';
import '../widget/templates.dart';
import 'lrt_detail_screen.dart'; // <--- BARIS INI DITAMBAHKAN

class LrtScreen extends StatelessWidget {
  const LrtScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("LRT Jakarta")),
      body: FutureBuilder<List<LrtPenumpang>>(
        future: LrtAPI.fetchPenumpang(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Templates.loadingWidget();
          } else if (snapshot.hasError) {
            return Templates.errorWidget(snapshot.error.toString());
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("Data tidak tersedia."));
          } else {
            final data = snapshot.data!;
            return ListView.builder(
              itemCount: data.length,
              itemBuilder: (context, index) {
                final LrtPenumpang lrtItem = data[index]; // <--- BARIS INI DITAMBAHKAN/DIUBAH

                return InkWell( // <--- BARIS INI DITAMBAHKAN
                  onTap: () { // <--- BARIS INI DITAMBAHKAN
                    // Navigasi ke LrtDetailScreen saat card diklik
                    Navigator.push( // <--- BARIS INI DITAMBAHKAN
                      context, // <--- BARIS INI DITAMBAHKAN
                      MaterialPageRoute( // <--- BARIS INI DITAMBAHKAN
                        builder: (context) => LrtDetailScreen(lrtData: lrtItem), // <--- BARIS INI DITAMBAHKAN
                      ), // <--- BARIS INI DITAMBAHKAN
                    ); // <--- BARIS INI DITAMBAHKAN
                  }, // <--- BARIS INI DITAMBAHKAN
                  child: Templates.lrtPenumpangCard(lrtItem), // <--- BARIS INI DIUBAH (data[index] menjadi lrtItem)
                ); // <--- BARIS INI DITAMBAHKAN
              },
            );
          }
        },
      ),
    );
  }
}
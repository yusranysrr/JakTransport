// lib/screens/mrt_penumpang_detail_screen.dart

import 'package:flutter/material.dart';
import '../models/mrt_model.dart'; // Import model MRT

class MrtPenumpangDetailScreen extends StatelessWidget {
  final MrtPenumpang penumpang; // Menerima objek MrtPenumpang

  const MrtPenumpangDetailScreen({Key? key, required this.penumpang}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = Theme.of(context).primaryColor;
    final Color textColorForAppBar = Colors.white;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Detail Penumpang MRT', // Judul AppBar
          style: TextStyle(
            color: textColorForAppBar,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: primaryColor,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          elevation: 8.0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Icon(
                    Icons.people, // Ikon untuk penumpang
                    size: 80,
                    color: primaryColor,
                  ),
                ),
                const SizedBox(height: 24),

                // Detail Periode
                _buildDetailItem(
                  context,
                  icon: Icons.date_range, // Ikon untuk periode
                  label: 'Periode Data',
                  value: penumpang.periode,
                ),
                const SizedBox(height: 16),

                // Detail Bulan <<< BARIS BARU DITAMBAHKAN
                _buildDetailItem( // <<< BARIS BARU DITAMBAHKAN
                  context, // <<< BARIS BARU DITAMBAHKAN
                  icon: Icons.calendar_month, // Ikon untuk bulan <<< BARIS BARU DITAMBAHKAN
                  label: 'Bulan', // <<< BARIS BARU DITAMBAHKAN
                  value: penumpang.bulan, // Menggunakan data bulan dari model <<< BARIS BARU DITAMBAHKAN
                ), // <<< BARIS BARU DITAMBAHKAN
                const SizedBox(height: 16), // <<< BARIS BARU DITAMBAHKAN

                // Detail Jumlah Penumpang
                _buildDetailItem(
                  context,
                  icon: Icons.person_add, // Ikon untuk jumlah penumpang
                  label: 'Jumlah Penumpang',
                  value: penumpang.jumlah,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Helper method untuk membangun setiap baris detail dengan ikon (sama seperti sebelumnya)
  Widget _buildDetailItem(BuildContext context, {required IconData icon, required String label, required String value}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: Theme.of(context).colorScheme.secondary, size: 20),
            const SizedBox(width: 8),
            Text(
              '$label:',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).primaryColor,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.only(left: 28.0),
          child: Text(
            value,
            style: const TextStyle(fontSize: 18),
          ),
        ),
      ],
    );
  }
}
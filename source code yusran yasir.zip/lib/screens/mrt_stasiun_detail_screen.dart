// lib/screens/mrt_stasiun_detail_screen.dart

import 'package:flutter/material.dart';
import '../models/mrt_model.dart'; // Import model MRT

class MrtStasiunDetailScreen extends StatelessWidget {
  final MrtStasiun stasiun; // Menerima objek MrtStasiun

  const MrtStasiunDetailScreen({Key? key, required this.stasiun}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = Theme.of(context).primaryColor;
    final Color textColorForAppBar = Colors.white;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          stasiun.namaStasiun, // Judul AppBar adalah nama stasiun
          style: TextStyle(
            color: textColorForAppBar,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: primaryColor,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          elevation: 8.0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Icon(
                    Icons.train, // Ikon untuk stasiun MRT
                    size: 80,
                    color: primaryColor,
                  ),
                ),
                const SizedBox(height: 24),

                // Detail Nama Stasiun
                _buildDetailItem(
                  context,
                  icon: Icons.push_pin,
                  label: 'Nama Stasiun',
                  value: stasiun.namaStasiun,
                ),
                const SizedBox(height: 16),

                // Detail Alamat
                _buildDetailItem(
                  context,
                  icon: Icons.place,
                  label: 'Alamat',
                  value: stasiun.alamat,
                ),
                const SizedBox(height: 16),

                // Detail Wilayah
                _buildDetailItem(
                  context,
                  icon: Icons.location_city,
                  label: 'Wilayah',
                  value: stasiun.wilayah,
                ),
                const SizedBox(height: 16),

                // Detail Kecamatan
                _buildDetailItem(
                  context,
                  icon: Icons.map,
                  label: 'Kecamatan',
                  value: stasiun.kecamatan,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Helper method untuk membangun setiap baris detail dengan ikon (sama seperti sebelumnya)
  Widget _buildDetailItem(BuildContext context, {required IconData icon, required String label, required String value}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: Theme.of(context).colorScheme.secondary, size: 20),
            const SizedBox(width: 8),
            Text(
              '$label:',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).primaryColor,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.only(left: 28.0),
          child: Text(
            value,
            style: const TextStyle(fontSize: 18),
          ),
        ),
      ],
    );
  }
}
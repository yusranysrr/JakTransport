import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/mrt_model.dart';

class MrtAPI {
  static Future<List<MrtPenumpang>> fetchPenumpang() async {
    final url = 'https://ws.jakarta.go.id/gateway/DataPortalSatuDataJakarta/1.0/satudata?kategori=dataset&tipe=detail&url=data-jumlah-penumpang-mass-rapid-transit-mrt';
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List list = data['data'];
      return list.map((e) => MrtPenumpang.fromJson(e)).toList();
    } else {
      throw Exception('Gagal mengambil data penumpang MRT');
    }
  }

  static Future<List<MrtStasiun>> fetchStasiun() async {
    final url = 'https://ws.jakarta.go.id/gateway/DataPortalSatuDataJakarta/1.0/satudata?kategori=dataset&tipe=detail&url=data-stasiun-mass-rapid-transit-mrt';
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List list = data['data'];
      return list.map((e) => MrtStasiun.fromJson(e)).toList();
    } else {
      throw Exception('Gagal mengambil data stasiun MRT');
    }
  }
}

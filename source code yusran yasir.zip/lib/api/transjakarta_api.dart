import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/transjakarta_model.dart';

class TransjakartaAPI {
  static Future<List<TransjakartaJumlah>> fetchJumlah() async {
    final url = 'https://ws.jakarta.go.id/gateway/DataPortalSatuDataJakarta/1.0/satudata?kategori=dataset&tipe=detail&url=data-jumlah-bus-yang-beroperasi-dan-jumlah-penumpang-layanan-transjakarta';
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List list = data['data'];
      return list.map((e) => TransjakartaJumlah.fromJson(e)).toList();
    } else {
      throw Exception('Gagal mengambil data jumlah');
    }
  }

  static Future<List<TransjakartaHalte>> fetchHalte() async {
    final url = 'https://ws.jakarta.go.id/gateway/DataPortalSatuDataJakarta/1.0/satudata?kategori=dataset&tipe=detail&url=data-halte-transjakarta';
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List list = data['data'];
      return list.map((e) => TransjakartaHalte.fromJson(e)).toList();
    } else {
      throw Exception('Gagal mengambil data halte');
    }
  }

  static Future<List<TransjakartaRute>> fetchRute() async {
    final url = 'https://ws.jakarta.go.id/gateway/DataPortalSatuDataJakarta/1.0/satudata?kategori=dataset&tipe=detail&url=data-rute-jalur-transjakarta';
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List list = data['data'];
      return list.map((e) => TransjakartaRute.fromJson(e)).toList();
    } else {
      throw Exception('Gagal mengambil data rute');
    }
  }
}

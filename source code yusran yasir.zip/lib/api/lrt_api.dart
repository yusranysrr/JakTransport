import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/lrt_model.dart';

class LrtAPI {
  static Future<List<LrtPenumpang>> fetchPenumpang() async {
    final url = 'https://ws.jakarta.go.id/gateway/DataPortalSatuDataJakarta/1.0/satudata?kategori=dataset&tipe=detail&url=data-penumpang-lrt-di-provinsi-dki-jakarta';
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List list = data['data'];
      return list.map((e) => LrtPenumpang.fromJson(e)).toList();
    } else {
      throw Exception('Gagal mengambil data penumpang LRT');
    }
  }
}
